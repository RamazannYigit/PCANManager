#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QTextStream>
#include <QRegularExpression>
#include <cmath>
#include <QHBoxLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QtCharts>
#include <QSet>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , isConnected(false)
{
    ui->setupUi(this);
    setupFilterWidgets();
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::readMessages);
    setupGraph();
    connect(ui->messageTable, &QTableWidget::itemClicked, this, &MainWindow::onMessageTableItemClicked);
    connect(ui->showGraphButton, &QPushButton::clicked, this, &MainWindow::onShowGraphClicked);
    connect(ui->exportToCsvButton, &QPushButton::clicked, this, &MainWindow::exportToCSV);
    connect(ui->transmitTable, &QTableWidget::itemDoubleClicked, this, &MainWindow::onTransmitTableItemDoubleClicked);

    // Başlangıçta bu butonları devre dışı bırak
    ui->showGraphButton->setEnabled(false);
    ui->exportToCsvButton->setEnabled(false);

    setupTransmitTab();
    updateUIState();

    // Yeni: dataLineEdit'ler için otomatik geçiş özelliğini ayarla
    setupDataLineEdits();

    // Transmit tablosunu ve checkbox'ları ayarla
    setupTransmitTable();

}

MainWindow::~MainWindow()
{
    if (isConnected) {
        disconnectPCAN();
    }
    delete ui;
    delete chart;
    delete series;
}

void MainWindow::on_connectButton_clicked()
{
    if (!isConnected) {
        initializePCAN();
    }
}

void MainWindow::on_disconnectButton_clicked()
{
    if (isConnected) {
        disconnectPCAN();
    }
}

void MainWindow::on_loadDbcButton_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this, "Open DBC File", "", "DBC Files (*.dbc)");
    if (!filename.isEmpty()) {
        if (parseDbcFile(filename)) {
            QFileInfo fileInfo(filename);
            ui->dbcFileNameLabel->setText(fileInfo.fileName());
            QMessageBox::information(this, "Success", "DBC file loaded successfully.");
        } else {
            ui->dbcFileNameLabel->setText("No DBC file loaded");
            QMessageBox::warning(this, "Error", "Failed to load DBC file.");
        }
    }
}

void MainWindow::initializePCAN()
{
    TPCANStatus result = CAN_Initialize(PCAN_USBBUS1, PCAN_BAUD_500K);
    if (result == PCAN_ERROR_OK) {
        isConnected = true;
        ui->statusbar->showMessage("Connected to PCAN");
        timer->start(100);
        transmitTimer->start(10); // Transmit timer'ı yeniden başlat
        updateUIState();

        // Transmit mesajlarını yeniden etkinleştir
        for (auto it = transmitMessages.begin(); it != transmitMessages.end(); ++it) {
            for (const auto &messageInfo : it.value()) {
                if (messageInfo.enabled && messageInfo.cycleTime > 0) {
                    transmitMessage(it.key());
                    break; // Her ID için bir kez transmitMessage çağırmak yeterli
                }
            }
        }
    } else {
        QMessageBox::critical(this, "Error", "Failed to initialize PCAN.");
    }
}

void MainWindow::disconnectPCAN()
{
    timer->stop();
    transmitTimer->stop(); // Transmit timer'ı durdur

    // Tüm transmit işlemlerini durdur
    for (auto it = transmitMessages.begin(); it != transmitMessages.end(); ++it) {
        for (auto &messageInfo : it.value()) {
            messageInfo.enabled = false; // Her mesajı devre dışı bırak
        }
    }

    TPCANStatus result = CAN_Uninitialize(PCAN_USBBUS1);
    if (result == PCAN_ERROR_OK) {
        isConnected = false;
        ui->statusbar->showMessage("Disconnected from PCAN");
        // Tabloları temizle
        ui->messageTable->setRowCount(0);
        ui->rawMessageTable->setRowCount(0);
        // rowMap'i temizle
        rowMap.clear();
        // Grafik verisini temizle
        if (series) {
            series->clear();
        }
        // Transmit verilerini temizle
        clearTransmitData();
        updateUIState();
    } else {
        QMessageBox::critical(this, "Error", "Failed to uninitialize PCAN.");
    }
}

void MainWindow::clearTransmitData()
{
    transmitMessages.clear();
    ui->transmitTable->setRowCount(0);
    ui->idLineEdit->clear();
    ui->cycleTimeSpinBox->setValue(100); // Varsayılan değere döndür

    // Tüm dataLineEdit_X alanlarını temizle
    for (int i = 0; i < 8; ++i) {
        QLineEdit* lineEdit = findChild<QLineEdit*>(QString("dataLineEdit_%1").arg(i));
        if (lineEdit) {
            lineEdit->clear();
        }
    }
}

void MainWindow::readMessages()
{
    if (!isConnected) {
        return;  // Bağlı değilse, veri okumayı durdur
    }

    TPCANMsg msg;
    TPCANTimestamp timestamp;

    while (CAN_Read(PCAN_USBBUS1, &msg, &timestamp) == PCAN_ERROR_OK) {
        interpretMessage(msg);
    }
}


bool MainWindow::parseDbcFile(const QString &filename)
{
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;

    QTextStream in(&file);
    QString line;
    quint32 currentMsgId = 0;
    QString currentMsgName;

    QRegularExpression signalRegex("SG_\\s+(\\w+)\\s+:\\s+(\\d+)\\|(\\d+)@\\d+\\s*([+-])\\s*\\(([^,]+),([^\\)]+)\\)\\s*\\[([^\\|]*)\\|([^\\]]*)\\]\\s*\"([^\"]*)\"");

    while (!in.atEnd()) {
        line = in.readLine().trimmed();
        if (line.startsWith("BO_ ")) {
            QStringList parts = line.split(" ");
            if (parts.size() >= 3) {
                currentMsgId = parts[1].toUInt();
                currentMsgName = parts[2].remove(':');
                dbcData[currentMsgId] = qMakePair(currentMsgName, QVector<Signal>());
            }
        } else if (line.startsWith("SG_ ")) {
            QRegularExpressionMatch match = signalRegex.match(line);
            if (match.hasMatch() && dbcData.contains(currentMsgId)) {
                Signal signal;
                signal.name = match.captured(1);
                signal.startBit = match.captured(2).toInt();
                signal.length = match.captured(3).toInt();
                signal.factor = match.captured(5).toDouble();
                signal.offset = match.captured(6).toDouble();
                signal.unit = match.captured(9);
                dbcData[currentMsgId].second.append(signal);
            }
        }
    }

    file.close();
    return true;
}

void MainWindow::interpretMessage(const TPCANMsg &msg)
{
    // Mevcut DBC tablosu güncellemesi
    if (dbcData.contains(msg.ID)) {
        const auto &msgInfo = dbcData[msg.ID];
        for (const auto &signal : msgInfo.second) {
            double value = extractSignalValue(msg, signal);

            QString rowKey = QString("%1_%2").arg(signal.name).arg(msg.ID);

            int row;
            if (!rowMap.contains(rowKey)) {
                row = ui->messageTable->rowCount();
                ui->messageTable->insertRow(row);

                QTableWidgetItem *nameItem = new QTableWidgetItem(signal.name);
                nameItem->setData(Qt::UserRole, rowKey);
                ui->messageTable->setItem(row, 0, nameItem);

                ui->messageTable->setItem(row, 1, new QTableWidgetItem(QString("0x%1").arg(msg.ID, 3, 16, QChar('0'))));
                ui->messageTable->setItem(row, 2, new QTableWidgetItem(signal.unit));

                rowMap[rowKey] = row;
            } else {
                row = rowMap[rowKey];
            }

            ui->messageTable->setItem(row, 3, new QTableWidgetItem(QString::number(value, 'f', 2)));
        }
    }

    // Raw veri tablosu güncellemesi
    updateRawMessageTable(msg);
    applyFilters();
}

void MainWindow::updateRawMessageTable(const TPCANMsg &msg)
{
    QString idStr = QString("0x%1").arg(msg.ID, 3, 16, QChar('0'));

    // ID için satır var mı kontrol et
    int row = -1;
    for (int i = 0; i < ui->rawMessageTable->rowCount(); ++i) {
        if (ui->rawMessageTable->item(i, 0)->text() == idStr) {
            row = i;
            break;
        }
    }

    // Eğer satır yoksa, yeni bir satır ekle
    if (row == -1) {
        row = ui->rawMessageTable->rowCount();
        ui->rawMessageTable->insertRow(row);
        ui->rawMessageTable->setItem(row, 0, new QTableWidgetItem(idStr));
    }

    // Veri baytlarını güncelle
    for (int i = 0; i < 8; ++i) {
        if (i < msg.LEN) {
            ui->rawMessageTable->setItem(row, i + 1, new QTableWidgetItem(QString("%1").arg(msg.DATA[i], 2, 16, QChar('0'))));
        } else {
            ui->rawMessageTable->setItem(row, i + 1, new QTableWidgetItem(""));
        }
    }
}
void MainWindow::updateUIState()
{
    ui->connectButton->setEnabled(!isConnected);
    ui->disconnectButton->setEnabled(isConnected);
    ui->loadDbcButton->setEnabled(!isConnected);

    // Show Graph ve Export to CSV butonlarını sadece bağlıyken etkinleştir
    ui->showGraphButton->setEnabled(isConnected);
    ui->exportToCsvButton->setEnabled(isConnected);
    ui->applyFilterButton->setEnabled(isConnected);

    // Transmit butonunu ve ilgili giriş alanlarını sadece bağlıyken etkinleştir
    ui->transmitButton->setEnabled(isConnected);
    ui->idLineEdit->setEnabled(isConnected);
    ui->cycleTimeSpinBox->setEnabled(isConnected);

    // Tüm dataLineEdit_X alanlarını etkinleştir/devre dışı bırak
    for (int i = 0; i < 8; ++i) {
        QLineEdit* lineEdit = findChild<QLineEdit*>(QString("dataLineEdit_%1").arg(i));
        if (lineEdit) {
            lineEdit->setEnabled(isConnected);
        }
    }
}

double MainWindow::extractSignalValue(const TPCANMsg &msg, const Signal &signal)
{
    quint64 rawValue = 0;
    int remainingBits = signal.length;
    int currentByte = signal.startBit / 8;
    int bitOffset = signal.startBit % 8;

    while (remainingBits > 0 && currentByte < 8) {
        int bitsToRead = qMin(8 - bitOffset, remainingBits);
        quint64 mask = ((1ULL << bitsToRead) - 1) << bitOffset;
        rawValue |= ((msg.DATA[currentByte] & mask) >> bitOffset) << (signal.length - remainingBits);

        remainingBits -= bitsToRead;
        currentByte++;
        bitOffset = 0;
    }

    return rawValue * signal.factor + signal.offset;
}
void MainWindow::setupFilterWidgets()
{
    connect(ui->applyFilterButton, &QPushButton::clicked, this, &MainWindow::applyFilters);
}

void MainWindow::on_applyFilterButton_clicked()
{
    QString idFilterText = ui->idFilterEdit->text().toLower();
    idFilters.clear();
    QStringList idList = idFilterText.split(",", Qt::SkipEmptyParts);
    for (const QString &id : idList) {
        idFilters.insert(id.trimmed());
    }
    applyFilters();
}

void MainWindow::applyFilters()
{
    QString signalFilter = ui->signalFilterEdit->text().toLower();

    for (int row = 0; row < ui->messageTable->rowCount(); ++row) {
        QString id = ui->messageTable->item(row, 1)->text().toLower();
        QString signalName = ui->messageTable->item(row, 0)->text().toLower();

        bool show = passesFilter(id, signalName);
        ui->messageTable->setRowHidden(row, !show);
    }
}

bool MainWindow::passesFilter(const QString &id, const QString &signalName)
{
    bool idMatch = idFilters.isEmpty() || idFilters.contains(id);
    bool signalMatch = ui->signalFilterEdit->text().isEmpty() || signalName.contains(ui->signalFilterEdit->text().toLower());

    return idMatch && signalMatch;
}

void MainWindow::setupGraph()
{
    chart = new QChart();
    series = new QLineSeries();
    chart->addSeries(series);

    // X ekseni için QDateTimeAxis kullan
    QDateTimeAxis *axisX = new QDateTimeAxis;
    axisX->setTickCount(5);
    axisX->setFormat("hh:mm:ss");
    axisX->setTitleText("Time");
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    // Y ekseni için QValueAxis kullan
    QValueAxis *axisY = new QValueAxis;
    axisY->setTitleText("Value");
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    chart->setTitle("Signal Graph");

    chartView = ui->chartView;
    chartView->setChart(chart);

    graphUpdateTimer = new QTimer(this);
    connect(graphUpdateTimer, &QTimer::timeout, this, &MainWindow::updateGraph);
}

void MainWindow::updateGraph()
{
    if (selectedSignal.isEmpty()) return;

    double maxY = 0;

    for (int row = 0; row < ui->messageTable->rowCount(); ++row) {
        if (ui->messageTable->item(row, 0)->text() == selectedSignal) {
            double value = ui->messageTable->item(row, 3)->text().toDouble();
            QDateTime currentTime = QDateTime::currentDateTime();
            series->append(currentTime.toMSecsSinceEpoch(), value);

            maxY = qMax(maxY, value);

            // Grafiği son 10 saniye ile sınırla
            QDateTime tenSecondsAgo = currentTime.addSecs(-10);
            while (series->count() > 0 && series->at(0).x() < tenSecondsAgo.toMSecsSinceEpoch()) {
                series->remove(0);
            }

            // X ekseni aralığını güncelle
            QDateTimeAxis *axisX = qobject_cast<QDateTimeAxis*>(chart->axes(Qt::Horizontal).first());
            if (axisX) {
                axisX->setRange(tenSecondsAgo, currentTime);
            }

            break;
        }
    }

    // Y ekseni aralığını 0'dan en yüksek değere kadar ayarla
    if (maxY > 0) {
        maxY *= 1.1;  // %10 fazlası
        QValueAxis *axisY = qobject_cast<QValueAxis*>(chart->axes(Qt::Vertical).first());
        if (axisY) {
            axisY->setRange(0, maxY);
        }
    }
}

void MainWindow::onShowGraphClicked()
{
    if (selectedSignal.isEmpty()) {
        QMessageBox::warning(this, "Warning", "Please select a signal first.");
        return;
    }

    series->clear();
    chart->setTitle(selectedSignal + " Graph");
    graphUpdateTimer->start(100);  // Her 100ms'de bir güncelle
    ui->tabWidget->setCurrentWidget(ui->graphTab);
}

void MainWindow::onMessageTableItemClicked(QTableWidgetItem *item)
{
    if (item->column() == 0) {  // Sinyal adı sütunu
        selectedSignal = item->text();
    }
}
void MainWindow::exportToCSV()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("Save CSV File"), "", tr("CSV Files (*.csv)"));
    if (fileName.isEmpty())
        return;

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
        return;

    QTextStream out(&file);
    out << "Time,Value\n";

    for (int i = 0; i < series->count(); ++i) {
        QPointF point = series->at(i);
        QDateTime time = QDateTime::fromMSecsSinceEpoch(point.x());
        out << time.toString("yyyy-MM-dd hh:mm:ss.zzz") << "," << QString::number(point.y()) << "\n";
    }

    file.close();
    QMessageBox::information(this, tr("Export Completed"), tr("Data has been exported to CSV successfully."));
}

void MainWindow::setupTransmitTab()
{
    transmitTimer = new QTimer(this);
    connect(transmitTimer, &QTimer::timeout, this, [this]() {
        for (auto it = transmitMessages.begin(); it != transmitMessages.end(); ++it) {
            transmitMessage(it.key());
        }
        updateTransmitTable();
    });
    transmitTimer->start(10); // Her 10 ms'de bir kontrol et
}

void MainWindow::on_transmitButton_clicked()
{
    bool ok;
    quint32 id = ui->idLineEdit->text().toUInt(&ok, 16);
    if (!ok) {
        QMessageBox::warning(this, "Error", "Invalid ID");
        return;
    }

    QByteArray data;
    for (int i = 0; i < 8; ++i) {
        QLineEdit* lineEdit = findChild<QLineEdit*>(QString("dataLineEdit_%1").arg(i));
        if (lineEdit) {
            QString byteStr = lineEdit->text();
            if (byteStr.isEmpty()) {
                data.append('\0');
            } else {
                bool ok;
                uint8_t byte = byteStr.toUInt(&ok, 16);
                if (!ok) {
                    QMessageBox::warning(this, "Error", QString("Invalid data in byte %1").arg(i));
                    return;
                }
                data.append(byte);
            }
        }
    }

    TPCANMsg msg;
    msg.ID = id;
    msg.LEN = 8;
    msg.MSGTYPE = (id > 0x7FF) ? PCAN_MESSAGE_EXTENDED : PCAN_MESSAGE_STANDARD;
    memcpy(msg.DATA, data.constData(), 8);

    int cycleTime = ui->cycleTimeSpinBox->value();

    TransmitMessageInfo messageInfo;
    messageInfo.msg = msg;
    messageInfo.cycleTime = cycleTime;
    messageInfo.enabled = true;
    messageInfo.count = 0;

    if (editingMessageIndex.first == id && editingMessageIndex.second != -1) {
        // Var olan mesajı güncelle
        if (transmitMessages.contains(id) && editingMessageIndex.second < transmitMessages[id].size()) {
            messageInfo.count = transmitMessages[id][editingMessageIndex.second].count;
            transmitMessages[id][editingMessageIndex.second] = messageInfo;
        }
    } else {
        // Yeni mesaj ekle
        if (!transmitMessages.contains(id)) {
            transmitMessages[id] = QVector<TransmitMessageInfo>();
        }
        transmitMessages[id].append(messageInfo);
    }

    updateTransmitTable();
    clearTransmitFields();
    editingMessageIndex = QPair<quint32, int>(-1, -1); // Düzenleme modunu sıfırla
}
void MainWindow::transmitMessage(int id)
{
    if (!isConnected || !transmitMessages.contains(id)) {
        return;
    }

    static QMap<int, QVector<QElapsedTimer>> lastTransmitTimes;

    if (!lastTransmitTimes.contains(id)) {
        lastTransmitTimes[id] = QVector<QElapsedTimer>(transmitMessages[id].size());
    }

    int baseRowIndex = getRowIndexForId(id);

    for (int i = 0; i < transmitMessages[id].size(); ++i) {
        if (i >= lastTransmitTimes[id].size()) {
            lastTransmitTimes[id].resize(i + 1);
        }

        auto &messageInfo = transmitMessages[id][i];

        // Checkbox kontrolü
        int currentRow = baseRowIndex + i;
        QWidget* widget = ui->transmitTable->cellWidget(currentRow, 4);
        QCheckBox *checkbox = qobject_cast<QCheckBox*>(widget);

        if (!checkbox || !checkbox->isChecked() || !messageInfo.enabled) {
            continue;
        }

        if (!lastTransmitTimes[id][i].isValid() || lastTransmitTimes[id][i].elapsed() >= messageInfo.cycleTime) {
            TPCANStatus result = CAN_Write(PCAN_USBBUS1, &messageInfo.msg);
            if (result == PCAN_ERROR_OK) {
                messageInfo.count++;
                lastTransmitTimes[id][i].start();
            } else {
                // Hata işleme kodu...
            }
        }
    }
}

void MainWindow::updateTransmitTable()
{
    int totalRows = 0;
    for (const auto &messages : transmitMessages) {
        totalRows += messages.size();
    }
    ui->transmitTable->setRowCount(totalRows);

    int row = 0;
    for (auto it = transmitMessages.begin(); it != transmitMessages.end(); ++it) {
        int id = it.key();
        for (int i = 0; i < it.value().size(); ++i) {
            const auto &messageInfo = it.value()[i];
            const TPCANMsg &msg = messageInfo.msg;

            // ID'yi güncelle veya ekle
            QTableWidgetItem *idItem = ui->transmitTable->item(row, 0);
            if (!idItem) {
                idItem = new QTableWidgetItem();
                ui->transmitTable->setItem(row, 0, idItem);
            }
            idItem->setText(QString("%1").arg(msg.ID, 0, 16).toUpper().rightJustified(3, '0'));

            // Veriyi güncelle veya ekle
            QTableWidgetItem *dataItem = ui->transmitTable->item(row, 1);
            if (!dataItem) {
                dataItem = new QTableWidgetItem();
                ui->transmitTable->setItem(row, 1, dataItem);
            }
            QString dataStr;
            for (int j = 0; j < 8; ++j) {
                dataStr += QString("%1 ").arg(msg.DATA[j], 2, 16, QChar('0'));
            }
            dataItem->setText(dataStr.trimmed());

            // Cycle time'ı güncelle veya ekle
            QTableWidgetItem *cycleTimeItem = ui->transmitTable->item(row, 2);
            if (!cycleTimeItem) {
                cycleTimeItem = new QTableWidgetItem();
                ui->transmitTable->setItem(row, 2, cycleTimeItem);
            }
            cycleTimeItem->setText(QString::number(messageInfo.cycleTime));

            // Count değerini güncelle
            QTableWidgetItem* countItem = ui->transmitTable->item(row, 3);
            if (!countItem) {
                countItem = new QTableWidgetItem("0");
                ui->transmitTable->setItem(row, 3, countItem);
            }
            countItem->setText(QString::number(messageInfo.count));

            // Checkbox'ı güncelle veya ekle
            QWidget* widget = ui->transmitTable->cellWidget(row, 4);
            QCheckBox *checkbox = qobject_cast<QCheckBox*>(widget);
            if (!checkbox) {
                checkbox = new QCheckBox(ui->transmitTable);
                ui->transmitTable->setCellWidget(row, 4, checkbox);

                connect(checkbox, &QCheckBox::stateChanged, this, [this, id, i](int state) {
                    if (transmitMessages.contains(id) && i < transmitMessages[id].size()) {
                        transmitMessages[id][i].enabled = (state == Qt::Checked);
                    }
                });
            }
            checkbox->setChecked(messageInfo.enabled);

            row++;
        }
    }
}

void MainWindow::clearTransmitFields()
{
    ui->idLineEdit->clear();
    for (int i = 0; i < 8; ++i) {
        QLineEdit* lineEdit = findChild<QLineEdit*>(QString("dataLineEdit_%1").arg(i));
        if (lineEdit) {
            lineEdit->clear();
        }
    }
    ui->cycleTimeSpinBox->setValue(100);  // Varsayılan değere döndür
}

void MainWindow::setupDataLineEdits()
{
    for (int i = 0; i < 8; ++i) {
        QLineEdit* lineEdit = findChild<QLineEdit*>(QString("dataLineEdit_%1").arg(i));
        if (lineEdit) {
            connect(lineEdit, &QLineEdit::textChanged, this, [this, i](const QString &text) {
                if (text.length() == 2) {
                    // Geçerli bir hex değeri mi kontrol et
                    bool ok;
                    text.toInt(&ok, 16);
                    if (ok) {
                        // Bir sonraki alana geç
                        if (i < 7) {
                            QLineEdit* nextLineEdit = findChild<QLineEdit*>(QString("dataLineEdit_%1").arg(i + 1));
                            if (nextLineEdit) {
                                nextLineEdit->setFocus();
                                nextLineEdit->selectAll();
                            }
                        } else {
                            // Son alandan sonra transmit butonuna odaklan
                            ui->transmitButton->setFocus();
                        }
                    }
                }
            });
        }
    }
}

void MainWindow::setupTransmitTable()
{
    // Tablo sütunlarını ayarla
    ui->transmitTable->setColumnCount(5);
    ui->transmitTable->setHorizontalHeaderLabels({"ID", "Data", "Cycle Time", "Count", "Enable"});

    // Sütun genişliklerini ayarla
    ui->transmitTable->setColumnWidth(0, 60);  // ID
    ui->transmitTable->setColumnWidth(1, 120); // Data
    ui->transmitTable->setColumnWidth(2, 80);  // Cycle Time
    ui->transmitTable->setColumnWidth(3, 60);  // Count
    ui->transmitTable->setColumnWidth(4, 50);  // Enable
}

void MainWindow::onTransmitTableItemDoubleClicked(QTableWidgetItem *item)
{
    int row = item->row();
    QString idStr = ui->transmitTable->item(row, 0)->text();
    quint32 id = idStr.toUInt(nullptr, 16);

    // Düzenlenen mesajın indeksini bul
    int baseRowIndex = getRowIndexForId(id);
    if (baseRowIndex != -1) {
        int messageIndex = row - baseRowIndex;
        editingMessageIndex = QPair<quint32, int>(id, messageIndex);

        // Mevcut verileri form alanlarına doldur
        ui->idLineEdit->setText(idStr);

        if (transmitMessages.contains(id) && messageIndex < transmitMessages[id].size()) {
            const TransmitMessageInfo &messageInfo = transmitMessages[id][messageIndex];
            const TPCANMsg &msg = messageInfo.msg;

            // Data alanlarını doldur
            for (int i = 0; i < 8; ++i) {
                QLineEdit* lineEdit = findChild<QLineEdit*>(QString("dataLineEdit_%1").arg(i));
                if (lineEdit) {
                    lineEdit->setText(QString("%1").arg(msg.DATA[i], 2, 16, QChar('0')));
                }
            }

            // Cycle time'ı ayarla
            ui->cycleTimeSpinBox->setValue(messageInfo.cycleTime);
        }
    } else {
        editingMessageIndex = QPair<quint32, int>(-1, -1);
    }
}

int MainWindow::getRowIndexForId(quint32 id)
{
    int rowIndex = 0;
    for (auto it = transmitMessages.begin(); it != transmitMessages.end(); ++it) {
        if (it.key() == id) {
            return rowIndex;
        }
        rowIndex += it.value().size();
    }
    return -1;
}
