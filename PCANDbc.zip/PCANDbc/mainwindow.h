#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QMap>
#include <QVector>
#include <Windows.h>
#include "PCANBasic.h"
#include <QTableWidget>
#include <QPushButton>
#include <QtCharts>
#include <QSet>
#include <cmath>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

struct Signal {
    QString name;
    int startBit;
    int length;
    double factor;
    double offset;
    QString unit;
};

struct TransmitMessageInfo {
    TPCANMsg msg;
    int cycleTime;
    bool enabled;
    int count;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_connectButton_clicked();
    void on_disconnectButton_clicked();
    void on_loadDbcButton_clicked();
    void readMessages();
    void on_applyFilterButton_clicked();
    void onShowGraphClicked();
    void onMessageTableItemClicked(QTableWidgetItem *item);
    void on_transmitButton_clicked();
    void onTransmitTableItemDoubleClicked(QTableWidgetItem *item);

private:
    Ui::MainWindow *ui;
    QTimer *timer;
    HANDLE h_PCAN;
    bool isConnected;
    QMap<quint32, QPair<QString, QVector<Signal>>> dbcData;
    QMap<QString, int> rowMap;
    QLineEdit *idFilterEdit;
    QLineEdit *signalFilterEdit;
    QPushButton *applyFilterButton;
    QChart *chart;
    QLineSeries *series;
    QChartView *chartView;
    QTimer *graphUpdateTimer;
    QString selectedSignal;
    QSet<QString> idFilters;
    QMap<int, QVector<TransmitMessageInfo>> transmitMessages; // ID'ye göre mesaj ve sayaç
    QTimer *transmitTimer;
    QMap<int, QCheckBox*> transmitCheckboxes;
    QPair<quint32, int> editingMessageIndex;
    int getRowIndexForId(quint32 id);


    void initializePCAN();
    void disconnectPCAN();
    void updateRawMessageTable(const TPCANMsg &msg);
    bool parseDbcFile(const QString &filename);
    void interpretMessage(const TPCANMsg &msg);
    double extractSignalValue(const TPCANMsg &msg, const Signal &signal);
    void updateUIState();
    void setupFilterWidgets();
    void applyFilters();
    bool passesFilter(const QString &id, const QString &signalName);
    void setupGraph();
    void updateGraph();
    void exportToCSV();
    void setupTransmitTab();
    void transmitMessage(int id);
    void updateTransmitTable();
    void clearTransmitData();
    void clearTransmitFields();
    void setupDataLineEdits();
    void setupTransmitTable();
};

#endif // MAINWINDOW_H
